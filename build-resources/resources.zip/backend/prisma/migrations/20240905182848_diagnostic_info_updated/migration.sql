-- AlterTable
ALTER TABLE "Diagnostic" ADD COLUMN     "isIndoorPaymentEnabled" BOOLEAN;
