-- AlterTable
ALTER TABLE "publicHospital" ALTER COLUMN "services" DROP NOT NULL,
ALTER COLUMN "introduction" DROP NOT NULL;
