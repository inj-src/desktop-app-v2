-- AlterTable
ALTER TABLE "Diagnostic" ADD COLUMN     "labFirstSign" TEXT,
ADD COLUMN     "labSecondSign" TEXT,
ADD COLUMN     "labThirdSign" TEXT;
