-- AlterTable
ALTER TABLE "Signatures" ALTER COLUMN "image" DROP NOT NULL;
