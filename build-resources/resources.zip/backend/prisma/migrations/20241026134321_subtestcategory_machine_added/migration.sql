-- AlterTable
ALTER TABLE "SubTestCategory" ADD COLUMN     "machine" TEXT NOT NULL DEFAULT '';
