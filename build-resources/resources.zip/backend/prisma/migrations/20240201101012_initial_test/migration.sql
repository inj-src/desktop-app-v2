-- AlterTable
ALTER TABLE "BillTest" ADD COLUMN     "isInitial" BOOLEAN NOT NULL DEFAULT false;
