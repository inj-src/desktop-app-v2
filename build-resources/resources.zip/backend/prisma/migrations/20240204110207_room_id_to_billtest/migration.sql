-- AlterTable
ALTER TABLE "BillTest" ADD COLUMN     "roomNo" TEXT;
