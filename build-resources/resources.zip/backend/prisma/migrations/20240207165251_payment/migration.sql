-- AlterTable
ALTER TABLE "Diagnostic" ADD COLUMN     "paymentAmount" DOUBLE PRECISION;
