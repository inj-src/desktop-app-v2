-- AlterEnum
ALTER TYPE "AppointmentStatus" ADD VALUE 'ON_GOING';

-- AlterEnum
ALTER TYPE "MessageStatus" ADD VALUE 'ON_HOLD';
