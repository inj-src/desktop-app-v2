-- AlterTable
ALTER TABLE "public"."SessionNotice" ADD COLUMN     "deletedAt" TIMESTAMP(3);
