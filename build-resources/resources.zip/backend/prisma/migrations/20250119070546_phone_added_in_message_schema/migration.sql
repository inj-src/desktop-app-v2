-- AlterTable
ALTER TABLE "Message" ADD COLUMN     "phone" TEXT;
