-- AlterTable
ALTER TABLE "public"."IndoorFieldVisibility" ADD COLUMN     "referredDoctorId" BOOLEAN NOT NULL DEFAULT false;
