-- AlterTable
ALTER TABLE "public"."VersionAdminSession" ADD COLUMN     "revokedReason" TEXT;
