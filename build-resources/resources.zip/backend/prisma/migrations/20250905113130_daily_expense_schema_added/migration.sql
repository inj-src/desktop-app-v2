-- AlterTable
ALTER TABLE "public"."DailyExpense" ADD COLUMN     "reason" TEXT,
ADD COLUMN     "referenceId" TEXT;
