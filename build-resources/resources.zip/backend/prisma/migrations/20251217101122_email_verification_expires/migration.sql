-- AlterTable
ALTER TABLE "public"."Employee" ADD COLUMN     "emailVerificationExpires" TIMESTAMP(3);
