-- AlterEnum
ALTER TYPE "AppointmentLabel" ADD VALUE 'RESERVED_SLOT';
