-- AlterTable
ALTER TABLE "TestTemplate" ADD COLUMN     "isItFromSuperAdmin" BOOLEAN NOT NULL DEFAULT false;
