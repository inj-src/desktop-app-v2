-- AlterTable
ALTER TABLE "public"."Bill" ADD COLUMN     "doctorCommissionAmount" DOUBLE PRECISION NOT NULL DEFAULT 0;
