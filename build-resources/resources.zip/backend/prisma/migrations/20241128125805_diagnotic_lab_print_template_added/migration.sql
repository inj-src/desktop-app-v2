-- AlterTable
ALTER TABLE "Diagnostic" ADD COLUMN     "printLabTemplate" INTEGER NOT NULL DEFAULT 1;
