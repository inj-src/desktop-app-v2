-- AlterTable
ALTER TABLE "OTPVerification" ADD COLUMN     "contextData" JSONB;
