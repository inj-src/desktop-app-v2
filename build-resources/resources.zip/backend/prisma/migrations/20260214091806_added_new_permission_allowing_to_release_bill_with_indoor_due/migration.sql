-- AlterTable
ALTER TABLE "public"."Diagnostic" ADD COLUMN     "allowIndoorReleaseWithIndoorDue" BOOLEAN NOT NULL DEFAULT false;
