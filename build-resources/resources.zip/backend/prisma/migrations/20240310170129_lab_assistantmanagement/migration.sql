-- AlterTable
ALTER TABLE "Diagnostic" ADD COLUMN     "isLabManagement" BOOLEAN;
