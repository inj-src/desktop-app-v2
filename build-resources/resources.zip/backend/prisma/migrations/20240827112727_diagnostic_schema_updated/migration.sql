-- AlterTable
ALTER TABLE "Diagnostic" ADD COLUMN     "roomCheckInDate" TIMESTAMP(3);
