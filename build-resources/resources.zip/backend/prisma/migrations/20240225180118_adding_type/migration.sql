-- AlterTable
ALTER TABLE "DailyExpense" ADD COLUMN     "type" TEXT;
