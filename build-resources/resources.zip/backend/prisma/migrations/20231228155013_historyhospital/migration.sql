-- AlterTable
ALTER TABLE "HospitalBill" ADD COLUMN     "type" TEXT NOT NULL DEFAULT 'new';
