-- AlterTable
ALTER TABLE "public"."Bill" ADD COLUMN     "isDoctorCommissionPaid" BOOLEAN NOT NULL DEFAULT false;
