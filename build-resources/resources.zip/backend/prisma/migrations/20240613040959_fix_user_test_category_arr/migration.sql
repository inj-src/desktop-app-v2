-- AlterTable
ALTER TABLE "User" ALTER COLUMN "userTestCategory" SET DATA TYPE TEXT[];
