-- AlterTable
ALTER TABLE "SMSPackagePurchase" ADD COLUMN     "approvedAt" TIMESTAMP(3);
