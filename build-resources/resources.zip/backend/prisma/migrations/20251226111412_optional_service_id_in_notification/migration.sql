-- AlterTable
ALTER TABLE "public"."Notification" ALTER COLUMN "serviceId" DROP NOT NULL;
