-- AlterTable
ALTER TABLE "publicDoctor" ALTER COLUMN "createdAt" DROP NOT NULL;


