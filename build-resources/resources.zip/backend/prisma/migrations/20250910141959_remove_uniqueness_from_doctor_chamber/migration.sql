-- DropIndex
DROP INDEX "public"."DoctorChamber_diagnosticId_uniqueId_key";
