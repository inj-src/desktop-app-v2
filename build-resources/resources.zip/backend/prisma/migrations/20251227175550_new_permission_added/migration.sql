-- AlterTable
ALTER TABLE "public"."Diagnostic" ADD COLUMN     "allowIndoorReleaseWithOutdoorDue" BOOLEAN NOT NULL DEFAULT false;
