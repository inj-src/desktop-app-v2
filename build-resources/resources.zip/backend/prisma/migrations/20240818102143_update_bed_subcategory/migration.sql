-- AlterTable
ALTER TABLE "BedSubCategory" ADD COLUMN     "price" INTEGER NOT NULL DEFAULT 0;
