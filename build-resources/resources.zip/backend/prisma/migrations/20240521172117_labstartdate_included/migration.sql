-- AlterTable
ALTER TABLE "Diagnostic" ADD COLUMN     "labStartDate" TIMESTAMP(3);
