-- AlterTable
ALTER TABLE "Commission" ADD COLUMN     "isIndoorCommission" BOOLEAN NOT NULL DEFAULT false;
