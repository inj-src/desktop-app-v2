-- AlterTable
ALTER TABLE "DailyExpense" ADD COLUMN     "isIndoorExpense" BOOLEAN NOT NULL DEFAULT false;
