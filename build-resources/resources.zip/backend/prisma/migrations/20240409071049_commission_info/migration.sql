-- AlterTable
ALTER TABLE "Commission" ADD COLUMN     "info" JSONB;
