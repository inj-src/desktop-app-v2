-- AlterTable
ALTER TABLE "Patient" ADD COLUMN     "photo" TEXT;
