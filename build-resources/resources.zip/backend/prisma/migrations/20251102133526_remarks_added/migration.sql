-- AlterTable
ALTER TABLE "public"."Bill" ADD COLUMN     "remarks" TEXT;

-- AlterTable
ALTER TABLE "public"."HospitalBill" ADD COLUMN     "remarks" TEXT;
