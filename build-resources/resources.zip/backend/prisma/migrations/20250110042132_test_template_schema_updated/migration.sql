-- AlterTable
ALTER TABLE "TestTemplate" ADD COLUMN     "sourceDiagnosticId" TEXT;
