-- AlterTable
ALTER TABLE "public"."DoctorAppointment" ADD COLUMN     "queuePosition" INTEGER NOT NULL DEFAULT 0;
