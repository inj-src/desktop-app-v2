-- AlterTable
ALTER TABLE "public"."DoctorChamber" ADD COLUMN     "queueDisplaySettings" JSONB NOT NULL DEFAULT '{}';
