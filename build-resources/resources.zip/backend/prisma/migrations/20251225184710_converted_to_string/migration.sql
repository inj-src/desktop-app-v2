-- AlterTable
ALTER TABLE "public"."Device" ALTER COLUMN "totalMemory" SET DATA TYPE TEXT;
