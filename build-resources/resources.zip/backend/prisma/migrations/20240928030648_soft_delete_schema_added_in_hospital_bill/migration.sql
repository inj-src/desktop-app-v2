-- AlterTable
ALTER TABLE "HospitalBill" ADD COLUMN     "deletedAt" TIMESTAMP(3);
