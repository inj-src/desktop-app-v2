-- AlterTable
ALTER TABLE "BillTest" ADD COLUMN     "order" INTEGER;
