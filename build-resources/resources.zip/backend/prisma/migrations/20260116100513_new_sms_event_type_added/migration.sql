-- AlterEnum
ALTER TYPE "public"."SMSEventType" ADD VALUE 'PC_PAYMENT';
