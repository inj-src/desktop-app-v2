-- AlterTable
ALTER TABLE "publicDoctorHospital" ADD COLUMN     "phone" TEXT,
ADD COLUMN     "time" TEXT;
