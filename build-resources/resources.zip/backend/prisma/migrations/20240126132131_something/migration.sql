-- AlterTable
ALTER TABLE "HospitalBill" ALTER COLUMN "status" SET DEFAULT 'Admitted';
