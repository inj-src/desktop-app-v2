-- AlterTable
ALTER TABLE "DoctorChamber" ADD COLUMN     "reservedSerialStrategies" JSONB NOT NULL DEFAULT '[]';
