-- AlterTable
ALTER TABLE "public"."Commission" ADD COLUMN     "isTestWise" BOOLEAN NOT NULL DEFAULT true;
