-- AlterTable
ALTER TABLE "public"."PCVisit" ADD COLUMN     "note" TEXT;
