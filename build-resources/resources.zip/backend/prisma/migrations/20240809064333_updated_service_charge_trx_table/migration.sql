-- AlterTable
ALTER TABLE "ServiceChargeTrx" ADD COLUMN     "serviceChrageLastPaymentDate" TIMESTAMP(3);
