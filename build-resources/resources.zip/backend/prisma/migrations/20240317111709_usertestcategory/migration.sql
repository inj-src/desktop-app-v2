-- AlterTable
ALTER TABLE "User" ADD COLUMN     "userTestCategory" INTEGER[];
