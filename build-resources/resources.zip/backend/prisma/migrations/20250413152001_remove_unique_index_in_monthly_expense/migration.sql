-- DropIndex
DROP INDEX "MonthlyExpense_monthlyExpenseCategoryId_diagnosticId_expens_key";
