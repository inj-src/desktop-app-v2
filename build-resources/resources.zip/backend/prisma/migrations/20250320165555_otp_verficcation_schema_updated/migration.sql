-- AlterTable
ALTER TABLE "OTPVerification" ALTER COLUMN "patientId" DROP NOT NULL;
