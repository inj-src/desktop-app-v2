-- AlterTable
ALTER TABLE "public"."Diagnostic" ADD COLUMN     "isAdmissionFeePaymentReceiver" BOOLEAN DEFAULT false;
