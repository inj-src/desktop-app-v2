-- DropIndex
DROP INDEX "BillTest_template_idx";
