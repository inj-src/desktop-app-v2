-- AlterTable
ALTER TABLE "SubTestCategory" ADD COLUMN     "order" INTEGER NOT NULL DEFAULT 1;
