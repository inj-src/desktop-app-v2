-- AlterTable
ALTER TABLE "ActiveToken" ADD COLUMN     "ipAddress" TEXT;
