-- AlterTable
ALTER TABLE "DoctorAppointment" ALTER COLUMN "serialNo" SET DATA TYPE TEXT;

-- AlterTable
ALTER TABLE "DoctorChamber" ALTER COLUMN "uniqueId" SET DATA TYPE TEXT;
