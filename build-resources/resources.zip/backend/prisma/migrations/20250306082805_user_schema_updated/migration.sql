-- AlterTable
ALTER TABLE "User" ADD COLUMN     "labFirstSign" TEXT,
ADD COLUMN     "labSecondSign" TEXT,
ADD COLUMN     "labThirdSign" TEXT;
