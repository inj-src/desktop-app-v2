-- AlterTable
ALTER TABLE "public"."DoctorChamber" ADD COLUMN     "marketingConfig" JSONB;
