-- AlterTable
ALTER TABLE "public"."VersionAdminSession" ADD COLUMN     "revokedAt" TIMESTAMP(3);
