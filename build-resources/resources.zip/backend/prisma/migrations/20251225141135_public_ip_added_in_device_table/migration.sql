-- AlterTable
ALTER TABLE "public"."Device" ADD COLUMN     "publicIP" TEXT;
