-- AlterTable
ALTER TABLE "HospitalBill" ADD COLUMN     "admissionDate" TIMESTAMP(3),
ADD COLUMN     "releasedDate" TIMESTAMP(3);
