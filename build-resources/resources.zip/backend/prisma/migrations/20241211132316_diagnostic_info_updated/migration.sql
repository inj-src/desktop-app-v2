-- AlterTable
ALTER TABLE "Diagnostic" ADD COLUMN     "minimumPercentageToPrint" INTEGER NOT NULL DEFAULT 0;
