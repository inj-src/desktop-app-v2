-- AlterTable
ALTER TABLE "public"."Commission" ALTER COLUMN "isTestWise" SET DEFAULT false;
