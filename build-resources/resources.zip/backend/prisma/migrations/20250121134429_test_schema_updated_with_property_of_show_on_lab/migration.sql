-- AlterTable
ALTER TABLE "Test" ADD COLUMN     "showOnLab" BOOLEAN DEFAULT true;
