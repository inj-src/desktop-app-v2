-- AlterTable
ALTER TABLE "public"."DiagnosticTemplate" ALTER COLUMN "templateId" DROP NOT NULL;
