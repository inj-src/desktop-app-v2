-- AlterTable
ALTER TABLE "public"."Diagnostic" ADD COLUMN     "printIndoorSummaryTemplate" INTEGER NOT NULL DEFAULT 1;
