-- AlterTable
ALTER TABLE "Bill" ADD COLUMN     "refundedAmount" INTEGER NOT NULL DEFAULT 0;
