-- AlterTable
ALTER TABLE "public"."PCVisit" ADD COLUMN     "metaData" JSONB;
