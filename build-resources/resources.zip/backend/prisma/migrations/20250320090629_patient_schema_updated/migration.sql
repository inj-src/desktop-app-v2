-- AlterTable
ALTER TABLE "Patient" ADD COLUMN     "enablePasswordBasedLogin" BOOLEAN NOT NULL DEFAULT false;
