-- DropIndex
DROP INDEX "SurgeonOperationTrx_surgeonOperationId_key";
