-- AlterTable
ALTER TABLE "Test" ADD COLUMN     "sample" TEXT;
