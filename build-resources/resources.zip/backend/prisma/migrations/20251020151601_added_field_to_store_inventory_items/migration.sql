-- AlterTable
ALTER TABLE "public"."StoreInventoryItems" ADD COLUMN     "manufactureDate" TIMESTAMP(3);
