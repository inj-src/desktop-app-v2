-- DropIndex
DROP INDEX "MonthlyExpenseCategory_name_diagnosticId_key";
