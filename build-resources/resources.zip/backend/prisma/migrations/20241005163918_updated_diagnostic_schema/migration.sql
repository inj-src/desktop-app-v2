-- AlterTable
ALTER TABLE "Diagnostic" ADD COLUMN     "canEditReleasedIndoorBill" BOOLEAN;
