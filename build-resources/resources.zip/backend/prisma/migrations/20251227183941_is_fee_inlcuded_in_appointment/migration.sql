-- AlterTable
ALTER TABLE "public"."DoctorAppointment" ADD COLUMN     "isFeeIncluded" BOOLEAN NOT NULL DEFAULT false;
