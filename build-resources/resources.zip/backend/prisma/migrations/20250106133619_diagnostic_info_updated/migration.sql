-- AlterTable
ALTER TABLE "Diagnostic" ADD COLUMN     "offlineLogo" TEXT,
ADD COLUMN     "showOnlyAdminDoctor" BOOLEAN;
