-- AlterTable
ALTER TABLE "HospitalBill" ADD COLUMN     "advanceInFee" INTEGER NOT NULL DEFAULT 0;
