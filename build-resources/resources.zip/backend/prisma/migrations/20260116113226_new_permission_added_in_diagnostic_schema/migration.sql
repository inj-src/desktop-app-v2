-- AlterTable
ALTER TABLE "public"."Diagnostic" ADD COLUMN     "sendSMSToAdminWhenPcPayment" BOOLEAN DEFAULT false;
