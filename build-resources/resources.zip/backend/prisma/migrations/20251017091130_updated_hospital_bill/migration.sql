-- AlterTable
ALTER TABLE "public"."HospitalBill" ADD COLUMN     "includeInventoryItemsInBill" BOOLEAN NOT NULL DEFAULT false;
