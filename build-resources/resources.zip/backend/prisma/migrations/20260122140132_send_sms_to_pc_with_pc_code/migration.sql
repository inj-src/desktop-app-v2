-- AlterTable
ALTER TABLE "public"."Diagnostic" ADD COLUMN     "sendSMSToPCWithPcCode" BOOLEAN DEFAULT false;
