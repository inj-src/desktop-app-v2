-- AlterTable
ALTER TABLE "public"."Bill" ADD COLUMN     "isAccessoriesIncludedInDiscountCalculation" BOOLEAN DEFAULT false;
