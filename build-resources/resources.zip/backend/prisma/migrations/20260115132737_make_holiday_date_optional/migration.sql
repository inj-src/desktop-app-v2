-- AlterTable
ALTER TABLE "public"."Holiday" ALTER COLUMN "date" DROP NOT NULL;
