-- AlterTable
ALTER TABLE "public"."DoctorChamber" ADD COLUMN     "prescriptionDoctorId" TEXT,
ADD COLUMN     "prescriptionHospitalId" TEXT;
