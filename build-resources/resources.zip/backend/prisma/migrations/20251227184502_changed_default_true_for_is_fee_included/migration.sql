-- AlterTable
ALTER TABLE "public"."DoctorAppointment" ALTER COLUMN "isFeeIncluded" SET DEFAULT true;
